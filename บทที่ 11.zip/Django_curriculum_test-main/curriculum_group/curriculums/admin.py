from django.contrib import admin
from .models import Faculty, Curriculum

admin.site.register(Faculty)
admin.site.register(Curriculum)